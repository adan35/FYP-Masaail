export default {
  api_url: 'http://localhost:8000/api',
  file_url: 'http://localhost:8000',
}