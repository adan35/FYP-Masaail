import Forgot from "./Forgot";
import Home from "./Home";
import Signin from "./Signin";
import OTP from "./OTP";
import SignUp from "./SignUp";

export { Forgot, Home, Signin, OTP, SignUp };
