import React from 'react'

const ChatBox = () => {
    return (
        <div>
            chatbox
        </div>
    )
}

export default ChatBox;