import Approvals from "./Approvals";
import Dashboard from "./Dashboard";
import Queries from "./Queries";
import Investors from "./Investors";
import Reviewers from "./Reviewers";

export { Approvals, Dashboard, Queries, Investors, Reviewers};