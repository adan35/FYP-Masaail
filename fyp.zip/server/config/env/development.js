"use strict";
module.exports = {
  PORT : 3000,
  MONGODB_URI : 'mongodb://localhost:27017/masail',
  secret : 'secret',
  host : '',
  smtpAuth: {
    user: 'ganjtony@gmail.com',
    pass: '12124545'
  },
};
